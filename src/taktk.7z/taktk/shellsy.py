from shellsy.shell import *


class shellsy(Shell):
    @Command
    def info(shell):
        print("hallo taktk world!")
